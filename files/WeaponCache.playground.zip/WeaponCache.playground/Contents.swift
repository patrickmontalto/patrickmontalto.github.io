// Generic Protocols
// Copyright (c) 2017 Patrick Montalto

import Foundation

protocol Weapon {
    func isEqual(to other: Weapon) -> Bool
}

// Protocol extension provides default implementation for Equatable conforming types
extension Weapon where Self:Equatable {
    func isEqual(to other: Weapon) -> Bool {
        if let other = other as? Self {
            return self == other
        }
        return false
    }
}

// Concrete classes Sword and Hammer conform to Weapon and Equatable
struct Sword: Weapon, Equatable {
    let name: String
    let sharpness: Int
    
    static func ==(lhs: Sword, rhs: Sword) -> Bool {
        return lhs.name == rhs.name && lhs.sharpness == rhs.sharpness
    }
}

struct Hammer: Weapon, Equatable {
    let name: String
    let weight: Int
    
    static func ==(lhs: Hammer, rhs: Hammer) -> Bool {
        return lhs.name == rhs.name && lhs.weight == rhs.weight
    }
}

// Collection wrapper WeaponCache conforms to Equatable by using our protocol extension default implementation
struct WeaponCache: Equatable {
    var weapons: [Weapon]
    
    static func ==(lhs: WeaponCache, rhs: WeaponCache) -> Bool {
        // Check if the caches contain the same amount of weapons
        if lhs.weapons.count == rhs.weapons.count {
            // Compare the collections of weapons in the caches
            return !zip(lhs.weapons, rhs.weapons).contains { !$0.isEqual(to: $1) }
        }
        return false
    }
}

var cache1 = WeaponCache(weapons:
    [Sword(name: "Master Sword", sharpness: 99),
     Hammer(name: "Bokoblin Club", weight: 23)])

var cache2 = WeaponCache(weapons:
    [Sword(name: "Rusty Sword", sharpness: 18),
     Hammer(name: "Bokoblin Club", weight: 23)])

cache1 == cache1 // true
cache1 == cache2 // false